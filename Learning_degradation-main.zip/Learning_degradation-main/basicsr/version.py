__version__ = '1.2.0+b5e17e3'
short_version = '1.2.0'
version_info = (1, 2, 0)
