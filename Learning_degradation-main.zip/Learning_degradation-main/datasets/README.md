Please Download GoPro test set for evaluation.
