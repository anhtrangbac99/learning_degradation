model checkpoint.
